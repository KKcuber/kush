#include "headers.h"

int main()
{
    init_shell();
    inputLoop();
}